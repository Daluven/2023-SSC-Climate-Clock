import SwiftUI
import Foundation

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup() {
            ContentView()
        }
    }
}

//

